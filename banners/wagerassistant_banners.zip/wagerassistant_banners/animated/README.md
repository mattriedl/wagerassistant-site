# WagerAssistant — Animated Banner Ads

Campaign: **"32 Free Betting Calculators"**  
Brand: navy `#0d0f1a`, gradient `#4f6ef7→#7c3aed`, accent `#a5b4fc`, green `#10b981`, Inter font  
Click-through URL: `https://wagerassistant.com`

## Contents

### HTML5 Animated Banners (`wagerassistant_<W>x<H>_html5/index.html`)
Self-contained HTML5 ad units with CSS `@keyframes` animation (no external JS libraries).
Each folder zips into a single ad-network-ready package (`wagerassistant_<W>x<H>_html5.zip`).

- Uses `clickTag` link wrapper pointing to `https://wagerassistant.com`
- Fonts: Inter (Google Fonts CDN) + Font Awesome 6 (CDN), degrades to `system-ui`
- Total animation duration: 5–8.5 seconds depending on size
- No flashing faster than 3 Hz; smooth professional motion

### Animated GIFs (`wagerassistant_<W>x<H>.gif`)
All GIFs rendered from the HTML5 animations via Playwright (1× device scale factor) + Pillow quantization.

| Size | Pixels (verified) | File Size | Frames | Loop | Total Duration |
|------|-------------------|-----------|--------|------|----------------|
| 160×600 | 160×600 | 144.7 KB | 9 | 3× | 27.0s |
| 250×250 | 250×250 | 144.4 KB | 11 | 3× | 23.1s |
| 300×250 | 300×250 | 149.6 KB | 11 | 3× | 26.4s |
| 300×600 | 300×600 | 136.9 KB | 6 | 3× | 27.0s |
| 320×50 | 320×50 | 133.7 KB | 26 | 3× | 15.6s |
| 336×280 | 336×280 | 139.2 KB | 11 | 3× | 26.4s |
| 468×60 | 468×60 | 124.6 KB | 23 | 3× | 17.2s |
| 728×90 | 728×90 | 138.8 KB | 11 | 3× | 19.8s |

**All GIFs ≤ 150 KB** (Google Display Network limit).  
**Loop**: 3× then hold on final CTA frame (Google Ads compliance: ≤ 30s total animation).

## Animation Storyboard

Adapted per size (smaller banners use fewer beats):

1. **Beat 1** — Logo + headline "32 Free Betting Calculators" slides/fades in
2. **Beat 2** — Tool names (Parlay • Arbitrage • Kelly • EV • Odds Converter) appear in sequence or pop in
3. **Beat 3** — "Free • Instant • No Signup" trust line fades in; CTA button "Try Free →" pulses/shines with `wagerassistant.com` visible
4. **Final frame** = matches the static banner design exactly

### Preview
Open `preview.html` to see all 8 animated GIFs on one contact sheet.
