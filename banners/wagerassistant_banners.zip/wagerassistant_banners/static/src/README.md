# WagerAssistant static banners — source

One HTML per size (`wagerassistant_WxH.html`), all sharing `banner.css` (brand tokens, logo, CTA, chips).
Re-render all PNGs (1x + @2x) into `../` with: `python3 render.py` (also reports any element overflowing the frame).

Element hooks for the animated versions (same on every size where present):
- `#banner` / `.wa-banner` – frame (1px #2a2f52 border, dot texture)
- `#glow` / `.wa-glow` – soft accent light (decorative)
- `#logo` / `.wa-logo` – ♠ icon (`.wa-logo-icon`) + wordmark (`.wa-logo-text`; 468x60 & 320x50 use the icon only, the URL carries the name)
- `#headline` / `.wa-headline` – "32 Free Betting Calculators" (`.wa-num` = gradient "32")
- `#subline` (728x90, 250x250) or `#tools` (chips / tool rows on larger sizes)
- `#trust` / `.wa-trust` – Free • Instant • No Signup
- `#cta` / `.wa-cta` – "Try Free →"
- `#url` / `.wa-url` – wagerassistant.com (on every size)
